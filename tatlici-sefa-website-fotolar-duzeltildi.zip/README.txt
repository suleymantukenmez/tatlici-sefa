TATLICI SEFA WEB SİTESİ

ZIP dosyasını çıkarın ve index.html dosyasını açın. assets klasörünü index.html ile aynı yerde tutun. Tek dosyalık HTML sürümünde görseller dosyanın içine gömülüdür.
